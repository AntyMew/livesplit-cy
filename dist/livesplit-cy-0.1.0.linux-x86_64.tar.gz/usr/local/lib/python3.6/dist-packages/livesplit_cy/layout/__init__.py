__all__ = ["component"]

from . import component
